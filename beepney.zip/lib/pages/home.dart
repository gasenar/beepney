import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

/* Authored by: Kryslone Dave D. Perez
Company: MITechnoverse
Project: Beepney
Feature: [BPNY-004] Beepney's Dashboard
User home page to display their available beepney balance
 */

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final CarouselController _controller = CarouselController();
  final List<String> imgList = [
    'assets/images/img1.png',
    'assets/images/img2.jpg',
    'assets/images/img3.jpg',
  ];
  int _current = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(65),
        child: Material(
          elevation: 15,
          child: AppBar(
            toolbarHeight: 65,
            title: const Text('Hello, abc',
                style: TextStyle(
                    fontSize: 20,
                    color: Colors.white,
                    fontFamily: 'IstokWeb',
                    fontWeight: FontWeight.bold)),
            backgroundColor: const Color.fromRGBO(07, 30, 51, 1),
            leading: SizedBox(
              width: 40,
              height: 40,
              child: Image.asset('assets/images/beepneyBlogo.png'),
            ),
            elevation: 0, // remove elevation from AppBar
            actions: <Widget>[
              Padding(
                padding: const EdgeInsets.only(
                    right: 19.0), // Adjust the padding as needed
                child: IconButton(
                  icon: const Icon(
                    Icons.notifications,
                    color: Colors.white,
                    size: 30,
                  ),
                  onPressed: () {},
                ),
              ),
            ],
          ),
        ),
      ),
      backgroundColor: const Color.fromRGBO(234, 234, 234, 1),
      body: SafeArea(
        child: SingleChildScrollView(
          child: LimitedBox(
            maxHeight: MediaQuery.of(context).size.height,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 15.0,
                    vertical: 15.0,
                  ),
                  child: Row(
                    children: [
                      ShaderMask(
                        shaderCallback: (bounds) => const LinearGradient(
                          colors: <Color>[
                            Color.fromRGBO(60, 186, 255, 1),
                            Color.fromRGBO(16, 71, 101, 1)
                          ],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ).createShader(bounds),
                        child: const Text(
                          'Overview',
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'IstokWeb',
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  width: 280,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: const Offset(0, 3),
                      ),
                    ],
                    gradient: const LinearGradient(
                      colors: <Color>[
                        Color.fromRGBO(60, 186, 255, 1),
                        Color.fromRGBO(16, 71, 101, 1)
                      ],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 10,
                          ),
                          Text('Available Balance',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'IstokWeb',
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold)),
                          SizedBox(
                            height: 10,
                          ),
                          Text('\u20B1 1000.00',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                              )),
                          SizedBox(
                            height: 45,
                          ),
                        ],
                      ),
                      Container(
                        alignment: Alignment.topRight,
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ShaderMask(
                              shaderCallback: (bounds) => const LinearGradient(
                                colors: <Color>[
                                  Color.fromRGBO(60, 186, 255, 1),
                                  Color.fromRGBO(16, 71, 101, 1)
                                ],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ).createShader(bounds),
                              child: const Text(
                                ' + Cash In ',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'IstokWeb',
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(
                  color: Colors.grey,
                  height: 40, // Reduced height
                  thickness: 1,
                  indent: 20,
                  endIndent: 20,
                ),
                CarouselSlider(
                  carouselController: _controller,
                  options: CarouselOptions(
                    height: 160,
                    autoPlay: true,
                    enlargeCenterPage: true,
                    enlargeFactor: 0.3,
                    onPageChanged: (index, reason) {
                      setState(() {
                        _current = index;
                      });
                    },
                  ),
                  items: imgList
                      .map((item) => Center(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(20.0),
                              child: Image.asset(item,
                                  fit: BoxFit.cover, width: 1000),
                            ),
                          ))
                      .toList(),
                ),
                const SizedBox(
                  height: 15,
                ),
                SmoothPageIndicator(
                  controller: PageController(initialPage: _current),
                  count: imgList.length,
                  effect: const ExpandingDotsEffect(
                    activeDotColor: Color.fromRGBO(07, 30, 51, 1),
                    dotColor: Colors.grey,
                    dotHeight: 8,
                    dotWidth: 8,
                  ),
                  onDotClicked: (index) {
                    _controller.animateToPage(index);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
