import 'package:flutter/material.dart';

/* Authored by: Christian E. Del Rosario
Company: MITechnoverse Innovation
Project: Beepney
Feature: [BPNY-002] Register Page
This is where the user will create their accounts. 
They need to fill the informations needed to create their accounts.
 */

class RegisterPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 360,
          height: 640,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(color: Colors.white),
          child: Stack(
            children: [
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment(0.00, -1.00),
                      end: Alignment(0, 1),
                      colors: [Colors.white, Color(0xFF073051)],
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 47,
                top: 251,
                child: Container(
                  width: 263,
                  height: 306,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(21),
                    ),
                    shadows: [
                      const BoxShadow(
                        color: Color(0x3F000000),
                        blurRadius: 4,
                        offset: Offset(0, 4),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 105,
                top: 454,
                child: Container(
                  width: 156,
                  height: 30,
                  child: Center(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => RegisterPage2()),
                        );
                      },
                      child: Text(
                        'PROCEED',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontFamily: 'Istok Web',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: Color(0xFF073051),
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
              ),
              Positioned(
                left: 79,
                top: 273,
                child: SizedBox(
                  width: 86,
                  child: Text(
                    'Phone number',
                    style: TextStyle(
                      color: Color(0xFF073051),
                      fontSize: 10,
                      fontFamily: 'Istok Web',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 77,
                top: 297,
                child: Container(
                  width: 202,
                  height: 20,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(width: 1, color: Color(0xFFC2C2C2)),
                    borderRadius: BorderRadius.circular(9),
                  ),
                ),
              ),
              Positioned(
                left: 84,
                top: 302,
                child: SizedBox(
                  width: 136,
                  child: Text(
                    'Enter a 10-digit phone number',
                    style: TextStyle(
                      color: Color(0xFFAAA9A9),
                      fontSize: 8,
                      fontFamily: 'Istok Web',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 79,
                top: 332,
                child: SizedBox(
                  width: 86,
                  child: Text(
                    'First Name',
                    style: TextStyle(
                      color: Color(0xFF073051),
                      fontSize: 10,
                      fontFamily: 'Istok Web',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 77,
                top: 356,
                child: Container(
                  width: 202,
                  height: 20,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(width: 1, color: Color(0xFFC2C2C2)),
                    borderRadius: BorderRadius.circular(9),
                  ),
                ),
              ),
              Positioned(
                left: 84,
                top: 361,
                child: SizedBox(
                  width: 136,
                  child: Text(
                    'Enter your first name',
                    style: TextStyle(
                      color: Color(0xFFAAA9A9),
                      fontSize: 8,
                      fontFamily: 'Istok Web',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 79,
                top: 385,
                child: SizedBox(
                  width: 86,
                  child: Text(
                    'Last Name',
                    style: TextStyle(
                      color: Color(0xFF073051),
                      fontSize: 10,
                      fontFamily: 'Istok Web',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 77,
                top: 408,
                child: Container(
                  width: 202,
                  height: 20,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(width: 1, color: Color(0xFFC2C2C2)),
                    borderRadius: BorderRadius.circular(9),
                  ),
                ),
              ),
              Positioned(
                left: 84,
                top: 412,
                child: SizedBox(
                  width: 136,
                  child: Text(
                    'Enter your last name',
                    style: TextStyle(
                      color: Color(0xFFAAA9A9),
                      fontSize: 8,
                      fontFamily: 'Istok Web',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 55,
                top: 0,
                child: Container(
                  width: 251,
                  height: 251,
                  child: Center(
                    child: Image.asset("assets/images/beepneymainlogo.png"),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

//the second part of register page

class RegisterPage2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 360,
          height: 640,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(color: Colors.white),
          child: Stack(
            children: [
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment(0.00, -1.00),
                      end: Alignment(0, 1),
                      colors: [Colors.white, Color(0xFF073051)],
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 47,
                top: 251,
                child: Container(
                  width: 263,
                  height: 306,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(21),
                    ),
                    shadows: [
                      const BoxShadow(
                        color: Color(0x3F000000),
                        blurRadius: 4,
                        offset: Offset(0, 4),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 105,
                top: 454,
                child: Container(
                  width: 156,
                  height: 30,
                  child: Center(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => RegisterPage()),
                        );
                      },
                      child: Text(
                        'PROCEED',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontFamily: 'Istok Web',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: Color(0xFF073051),
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
              ),
              Positioned(
                left: 79,
                top: 273,
                child: SizedBox(
                  width: 86,
                  child: Text(
                    'Full Address',
                    style: TextStyle(
                      color: Color(0xFF073051),
                      fontSize: 10,
                      fontFamily: 'Istok Web',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 77,
                top: 297,
                child: Container(
                  width: 202,
                  height: 20,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(width: 1, color: Color(0xFFC2C2C2)),
                    borderRadius: BorderRadius.circular(9),
                  ),
                ),
              ),
              Positioned(
                left: 84,
                top: 302,
                child: SizedBox(
                  width: 136,
                  child: Text(
                    'Building #, Street, City, Province, Country',
                    style: TextStyle(
                      color: Color(0xFFAAA9A9),
                      fontSize: 8,
                      fontFamily: 'Istok Web',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 79,
                top: 332,
                child: SizedBox(
                  width: 86,
                  child: Text(
                    'Email Address',
                    style: TextStyle(
                      color: Color(0xFF073051),
                      fontSize: 10,
                      fontFamily: 'Istok Web',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 77,
                top: 356,
                child: Container(
                  width: 202,
                  height: 20,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(width: 1, color: Color(0xFFC2C2C2)),
                    borderRadius: BorderRadius.circular(9),
                  ),
                ),
              ),
              Positioned(
                left: 84,
                top: 361,
                child: SizedBox(
                  width: 136,
                  child: Text(
                    'e.g juandelacruz@email.com',
                    style: TextStyle(
                      color: Color(0xFFAAA9A9),
                      fontSize: 8,
                      fontFamily: 'Istok Web',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 55,
                top: 0,
                child: Container(
                  width: 251,
                  height: 251,
                  child: Center(
                    child: Image.asset("assets/images/beepneymainlogo.png"),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class AccountRecoveryPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 360,
          height: 640,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(color: Color(0xFFEAEAEA)),
          child: Stack(
            children: [
              Positioned(
                left: 0,
                top: 0,
                child: Container(
                  width: 360,
                  height: 322,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment(0.00, -1.00),
                      end: Alignment(0, 1),
                      colors: [Colors.white, Color(0xFF073051)],
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 47,
                top: 241,
                child: Container(
                  width: 263,
                  height: 348,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(21),
                    ),
                    shadows: [
                      BoxShadow(
                        color: Color(0x3F000000),
                        blurRadius: 4,
                        offset: Offset(0, 4),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 105,
                top: 515,
                child: Container(
                  width: 156,
                  height: 30,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 46,
                        top: 7,
                        child: Text(
                          'PROCEED',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontFamily: 'Istok Web',
                            fontWeight: FontWeight.w700,
                            height: 0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 55,
                top: 0,
                child: Container(
                  width: 251,
                  height: 251,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image:
                          NetworkImage("https://via.placeholder.com/251x251"),
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 83,
                top: 346,
                child: Text(
                  'Enter recovery email\n',
                  style: TextStyle(
                    color: Color(0xFF073051),
                    fontSize: 10,
                    fontFamily: 'Istok Web',
                    fontWeight: FontWeight.w700,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 105,
                top: 273,
                child: Text(
                  'Recovery account ',
                  style: TextStyle(
                    color: Color(0xFF073051),
                    fontSize: 20,
                    fontFamily: 'Istok Web',
                    fontWeight: FontWeight.w700,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 92,
                top: 301,
                child: Text(
                  'Enter the email for the verification process.',
                  style: TextStyle(
                    color: Color(0xFF073051),
                    fontSize: 10,
                    fontFamily: 'Istok Web',
                    fontWeight: FontWeight.w400,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 109,
                top: 312,
                child: Text(
                  'We will send the code to your email',
                  style: TextStyle(
                    color: Color(0xFF073051),
                    fontSize: 10,
                    fontFamily: 'Istok Web',
                    fontWeight: FontWeight.w400,
                    height: 0,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
