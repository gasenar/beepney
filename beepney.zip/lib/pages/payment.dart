import 'package:flutter/material.dart';

class PaymentPage extends StatelessWidget {
  const PaymentPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.keyboard_arrow_left_rounded,
              color: Colors.white, size: 40),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('Payment',
            style: TextStyle(
                color: Colors.white,
                fontFamily: 'IstokWeb',
                fontSize: 25,
                fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: const Color.fromRGBO(07, 30, 51, 1),
        toolbarHeight: 90,
      ),
    );
  }
}
