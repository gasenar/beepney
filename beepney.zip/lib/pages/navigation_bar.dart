import 'package:flutter/material.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';
import 'home.dart';
import 'driver.dart';
import 'payment.dart';
import 'transaction.dart';
import 'profile.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

/* Authored by: Kryslone Dave D. Perez
Company: MITechnoverse
Project: Beepney
Feature: [BPNY-004] Beepney's Dashboard
Persistent Navigation Bar to navigate through different pages
 */

class Navbar extends StatefulWidget {
  const Navbar({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _NavbarState createState() => _NavbarState();
}

class _NavbarState extends State<Navbar> {
  late PersistentTabController _controller;

  @override
  void initState() {
    super.initState();
    _controller = PersistentTabController(initialIndex: 0);
    _controller.addListener(_handleTabChange);
  }

  void _handleTabChange() {
    if (_controller.index == 2) {
      // if the current tab is the payment tab
      _controller.jumpToTab(3); // skip to the transaction page
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PersistentTabView(
        gestureNavigationEnabled: true,
        navBarHeight: 60,
        controller: _controller,
        tabs: [
          PersistentTabConfig(
            screen: HomePage(),
            item: ItemConfig(
                activeForegroundColor: const Color.fromRGBO(07, 30, 51, 1),
                inactiveForegroundColor: Colors.grey,
                icon: const Icon(FontAwesomeIcons.house, size: 20),
                title: "Home",
                textStyle: const TextStyle(
                  fontFamily: 'IstokWeb',
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                )),
          ),
          PersistentTabConfig(
            screen: const DriverPage(),
            item: ItemConfig(
                activeForegroundColor: const Color.fromRGBO(07, 30, 51, 1),
                inactiveForegroundColor: Colors.grey,
                icon: const Icon(FontAwesomeIcons.idCard, size: 20),
                title: "Driver",
                textStyle: const TextStyle(
                  fontFamily: 'IstokWeb',
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                )),
          ),
          PersistentTabConfig.noScreen(
            item: ItemConfig(
                activeForegroundColor: const Color.fromRGBO(07, 30, 51, 1),
                icon: const Icon(
                  FontAwesomeIcons.qrcode,
                  color: Colors.white,
                ),
                title: "Pay",
                textStyle: const TextStyle(
                  fontFamily: 'IstokWeb',
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                )),
            onPressed: (context) {
              pushScreen(context,
                  screen: const PaymentPage(), withNavBar: false);
            },
          ),
          PersistentTabConfig(
            screen: const TransactionPage(),
            item: ItemConfig(
                activeForegroundColor: const Color.fromRGBO(07, 30, 51, 1),
                inactiveForegroundColor: Colors.grey,
                icon: const Icon(FontAwesomeIcons.receipt, size: 20),
                title: "Transaction",
                textStyle: const TextStyle(
                  fontFamily: 'IstokWeb',
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                )),
          ),
          PersistentTabConfig(
            screen: const ProfilePage(),
            item: ItemConfig(
                activeForegroundColor: const Color.fromRGBO(07, 30, 51, 1),
                inactiveForegroundColor: Colors.grey,
                icon: const Icon(
                  Icons.person,
                  size: 20,
                ),
                title: "Profile",
                textStyle: const TextStyle(
                  fontFamily: 'IstokWeb',
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                )),
          ),
        ],
        navBarBuilder: (navBarConfig) => Style13BottomNavBar(
          navBarConfig: navBarConfig,
          navBarDecoration: const NavBarDecoration(
            padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          ),
        ),
      ),
    );
  }
}
