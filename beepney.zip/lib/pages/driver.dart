import 'package:flutter/material.dart';

class DriverPage extends StatelessWidget {
  const DriverPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 90,
        title: const Text('Hello, Driver',
            style: TextStyle(
                color: Colors.white,
                fontFamily: 'IstokWeb',
                fontWeight: FontWeight.bold)),
        backgroundColor: const Color.fromRGBO(07, 30, 51, 1),
        leading: SizedBox(
          width: 50,
          height: 50,
          child: Image.asset('assets/images/B.png'),
        ),
      ),
    );
  }
}
