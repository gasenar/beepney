import 'package:beepney/pages/register_page.dart';
import 'package:flutter/material.dart';

/* Authored by: Gabriel V. Señar
Company: MITechnoverse
Project: Beepney
Feature: [BPNY-001] LoginPage
This is where the user will login their accounts if they have one
 */

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 360,
          height: 640,
          clipBehavior: Clip.antiAlias,
          decoration: const BoxDecoration(color: Color(0xFFFFFFFF)),
          child: Stack(
            children: [
              Positioned(
                left: 0,
                top: 0,
                child: Container(
                  width: 360,
                  height: 322,
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment(0.00, -1.00),
                      end: Alignment(0, 1),
                      colors: [Colors.white, Color(0xFF073051)],
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 47,
                top: 251,
                child: Container(
                  width: 263,
                  height: 306,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(21),
                    ),
                    shadows: const [
                      BoxShadow(
                        color: Color(0x3F000000),
                        blurRadius: 4,
                        offset: Offset(0, 4),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                ),
              ),
              const Positioned(
                left: 112,
                top: 491,
                child: Material(
                  child: Text(
                    'Didn’t have an account yet?',
                    style: TextStyle(
                      color: Color(0xFF140D0D),
                      fontSize: 8,
                      fontFamily: 'Roboto', // Updated font family
                      fontWeight: FontWeight.w400,
                      height: 0,
                    ),
                  ),
                ),
              ),
              Positioned(
                  left: 216,
                  top: 491,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => RegisterPage()),
                      );
                    },
                    child: const Material(
                      child: Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(
                              text: 'Sign Up',
                              style: TextStyle(
                                color: Color(0xFF140D0D),
                                fontSize: 8,
                                fontFamily: 'Roboto',
                                fontWeight: FontWeight.w700,
                                height: 0,
                              ),
                            ),
                            TextSpan(
                              text: ' ',
                              style: TextStyle(
                                color: Color(0xFF140D0D),
                                fontSize: 8,
                                fontFamily: 'Roboto',
                                fontWeight: FontWeight.w400,
                                height: 0,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  )),
              Positioned(
                left: 105,
                top: 454,
                child: Container(
                  width: 156,
                  height: 30,
                  child: const Stack(
                    children: [
                      Positioned(
                        left: 50,
                        top: 8,
                        child: Material(
                          child: Text(
                            'SIGN IN',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontFamily: 'Roboto', // Updated font family
                              fontWeight: FontWeight.w700,
                              height: 0,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const Positioned(
                left: 79,
                top: 273,
                child: SizedBox(
                  width: 86,
                  child: Material(
                    child: Text(
                      'Phone number',
                      style: TextStyle(
                        color: Color(0xFF073051),
                        fontSize: 10,
                        fontFamily: 'Roboto', // Updated font family
                        fontWeight: FontWeight.w700,
                        height: 0,
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 77,
                top: 297,
                child: Container(
                  width: 202,
                  height: 20,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      side:
                          const BorderSide(width: 1, color: Color(0xFFC2C2C2)),
                      borderRadius: BorderRadius.circular(9),
                    ),
                  ),
                ),
              ),
              const Positioned(
                left: 84,
                top: 302,
                child: SizedBox(
                  width: 136,
                  child: Material(
                    child: Text(
                      'Enter a 10-digit phone number',
                      style: TextStyle(
                        color: Color(0xFFAAA9A9),
                        fontSize: 8,
                        fontFamily: 'Roboto', // Updated font family
                        fontWeight: FontWeight.w400,
                        height: 0,
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 105,
                top: 454,
                child: Container(
                  width: 156,
                  height: 30,
                  decoration: BoxDecoration(
                    color: const Color(0xFF073051),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: const Center(
                    child: Material(
                      child: Text(
                        'SIGN IN',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontFamily: 'Roboto', // Updated font family
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const Positioned(
                left: 117,
                top: 510,
                child: Text(
                  'Forgot or lost your phone number? ',
                  style: TextStyle(
                    color: Color(0xFF140D0D),
                    fontSize: 8,
                    fontFamily: 'Roboto', // Updated font family
                    fontWeight: FontWeight.w400,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                  left: 148,
                  top: 522,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (content) => AccountRecoveryPage()),
                      );
                    },
                    child: const Text(
                      'Recover Account',
                      style: TextStyle(
                        color: Color(0xFF140D0D),
                        fontSize: 8,
                        fontFamily: 'Roboto', // Updated font family
                        fontWeight: FontWeight.w700,
                        height: 0,
                      ),
                    ),
                  )),
              Positioned(
                left: 55,
                top: 0,
                child: Container(
                  width: 251,
                  height: 251,
                  child: Center(
                      child: Image.asset("assets/images/beepneymainlogo.png")),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
